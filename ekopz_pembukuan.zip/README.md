## Setting env
### google login
```
GOOGLE_CLIENT_ID = {client_id}
GOOGLE_CLIENT_SECRET = {secret id}
GOOGLE_CLIENT_REDIRECT = {redirect google}
```

### Raja Ongkir
```
RAJAONGKIR_API_KEY={api rajaongkir}
```
