<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ShuController extends Controller
{
    //
}
